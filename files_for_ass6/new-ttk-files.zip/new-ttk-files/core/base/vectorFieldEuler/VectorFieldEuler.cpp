#include                  <VectorFieldEuler.h>

using namespace std;
using namespace ttk;

VectorFieldEuler::VectorFieldEuler(){

  inputDatax_ = NULL;
  inputDatay_ = NULL;
  triangulation_ = NULL;
  maxx = 0;
  maxy = 0;
  minx = 0;
  miny = 0;
}

VectorFieldEuler::~VectorFieldEuler(){

}

void VectorFieldEuler::coordsToVertex(pair<float,float> point, SimplexId& vertex){
  
  
  int vertex_number = triangulation_->getNumberOfVertices();
  float x,y,z;
  for(int i=0;i<vertex_number;i++){
    triangulation_->getVertexPoint(i,x,y,z);
    if(x==point.first && y== point.second){
      vertex=i;
      break;
    }
  }

}

bool VectorFieldEuler::isValidPoint(pair<float, float> point) {

  //from a pair of coordinates x and y return true if the point is inside the dataset
  if(point.first > maxx || point.first < minx || point.second > maxy || point.second< miny)
      return false;
  
  return true;
}

