/// \ingroup base
/// \class ttk::VectorFieldEuler
/// \author Your Name Here <Your Email Address Here>
/// \date The Date Here.
///
/// \brief TTK %vectorFieldEuler processing package.
///
/// %VectorFieldEuler is a TTK processing package that takes a scalar field on the input
/// and produces a scalar field on the output.
///
/// \sa ttk::Triangulation
/// \sa ttkVectorFieldEuler.cpp %for a usage example.

#pragma once

// base code includes
#include                  <Triangulation.h>
#include                  <Wrapper.h>

using namespace std;

namespace ttk{

  class VectorFieldEuler : public Debug {

  public:

      VectorFieldEuler();
      ~VectorFieldEuler();

      bool isValidPoint(pair<float, float> point);

      void coordsToVertex(pair<float,float> point, SimplexId& vertex);
  
      template<class dataType>
      bool pickNextVertex(pair<float, float> point, float dt, pair<float, float> &newPoint);
        
      template<class dataType>
      bool bilinearInterpolation(pair<float, float> point, pair<float, float> &vect);

      template<class dataType>
      int execute(int steps, float delta, vector<pair<float,float> >& line);


      inline int setInputDataPointer(void *datax, void *datay) {
          inputDatax_ = datax;
          inputDatay_ = datay;
          return 0;
      }


      inline int setupTriangulation(Triangulation *triangulation) {
          triangulation_ = triangulation;
          return 0;
      }

  protected:
      void *inputDatax_;
      void *inputDatay_;
      float minx,miny,maxx,maxy;
      Triangulation *triangulation_;
  };

}

template <class dataType> int ttk::VectorFieldEuler::execute(int steps, float delta, vector<pair<float,float> >& line) {
    //steps, number of steps for constructing the stream line
    //delta, increment used for the streamline
    //line, streamline to plot
dataType *inputDatax = (dataType *)inputDatax_; //this encodes the x component for each vector
  dataType *inputDatay = (dataType *)inputDatay_; //this encodes the y component for each vector
  
    int vertex_number = triangulation_->getNumberOfVertices();

// for forming the grid

    maxx=(sqrt(vertex_number)-1)/2;
    maxy=(sqrt(vertex_number)-1)/2;
    minx=(sqrt(vertex_number)-1)/2*(-1);
    miny=(sqrt(vertex_number)-1)/2*(-1);

    //initialize the stream line as collection of vertices
    line = vector<pair<float,float> >();

    //we define the first seed vertex as a pair of (x,y) coordinates
    pair<float,float> point;
    point.first = 0;
    point.second = -1;
    line.push_back(point);
    //cout<<"old point ="<<point.first<<point.second;    
    for(int i =0; i < steps; i++){
    pair<float,float> new_point;
            
        pickNextVertex<dataType>(point,delta,new_point);
        //cout<<"new point ="<<new_point.first<<new_point.second;        
        point=new_point;
        
        if(!isValidPoint(point)){
            break;        
        }
        line.push_back(point);

        line.push_back(point);
    }
    //we implement the loop for the Euler method here

      //pick the new vertex at each iteration (function pickNextvertex(...))

      //implement isValidPoint to check if the new vertex is valid

  return 0;
}


template <class dataType> bool ttk::VectorFieldEuler::pickNextVertex(pair<float,float> point, float dt, pair<float,float>& newPoint) {

SimplexId vertex;

    dataType *inputDatax = (dataType *)inputDatax_; //this encodes the x component for each vector
    dataType *inputDatay = (dataType *)inputDatay_; //this encodes the y component for each vector

    pair<float,float> vect;
    if(point.first == floor(point.first) && point.second == floor(point.second)){
       
        
        //cout<<point.first<< " " << point.second<<endl;
        coordsToVertex(point,vertex); // implement this
        //now that we have the vertex we can read it's components from inputDatax_ and inputDatay_
        vect.first =inputDatax[vertex];   //save here the x component for the vector
        vect.second =inputDatay[vertex]; //save herer the y component for the vector

    }
    else{
        //we are not on the grid, we have to compute the vector field by bilinear interpolation
        bilinearInterpolation<dataType>(point, vect);
    }
    //cout<<vect.first<<vect.second;

    newPoint.first=point.first+(vect.first*dt);

    newPoint.second=point.second+(vect.second*dt);

    //apply the euler formula here and store the coordinates in newPoint


    return true;



}

template <class dataType> bool ttk::VectorFieldEuler::bilinearInterpolation(pair<float,float> point, pair<float,float>& vect) {

    dataType *inputDatax = (dataType *)inputDatax_; //here is where the x component of each vector is stored
    dataType *inputDatay = (dataType *)inputDatay_; //here is where the y component of each vector is stored

    //retrieve all the values you need for implementing the formula
    //....
    int q11x,q12x,q21x,q22x;
    int q11y,q12y,q21y,q22y;
    float x,y;
    x=point.first;
    y=point.second;
    
    int x1=floor(x);
    int x2=floor(x)+1;

    int y1=floor(x);
    int y2=floor(x)+1;        
    
    pair<float,float> q11 = make_pair(x1,y1);
    pair<float,float> q12 = make_pair(x1,y2);
    pair<float,float> q21 = make_pair(x2,y1);
    pair<float,float> q22 = make_pair(x2,y2);
    
    SimplexId vertex_q11,vertex_q21,vertex_q12,vertex_q22;
    coordsToVertex(q11,vertex_q11);
    coordsToVertex(q12,vertex_q12);
    coordsToVertex(q21,vertex_q21);
    coordsToVertex(q22,vertex_q22);
    cout<<"hi0";
    
    dataType fvalx, fvaly,fvalx1,fvaly1,fvalx2,fvaly2;
    if(point.first != floor(point.first) && point.second == floor(point.second)){
      //implement linear interpolation
        float t = (x1-x)/(x1-x2);        
        fvalx=(((1-t)*inputDatax[vertex_q11])+t*(inputDatax[vertex_q21]));
        fvaly=(((1-t)*inputDatay[vertex_q12])+t*(inputDatay[vertex_q22]));

        cout<<"hie i am in x interpolation";
//fvalx=(x-x1)/(x2-x1)*
//
//
//        fvalx=(((1-t*input_x[vertex_q11])+t*(x2))+(((1-t)*x1*)+t*(x2));
  //      fvaly=y;  
    }
    else if(point.first == floor(point.first) && point.second != floor(point.second)){
      //implement linear interpolation
    cout<<"hi1";
        float t = (y1-y)/(y1-y2);
        fvalx=(((1-t)*inputDatax[vertex_q11])+t*(inputDatax[vertex_q21]));
        fvaly=(((1-t)*inputDatay[vertex_q12])+t*(inputDatay[vertex_q22]));
    }
    else{
      //full bilinear interpolation
        fvalx1=((x2-x)/(x2-x1))*inputDatax[vertex_q11] + ((x-x1)/(x2-x1))*inputDatax[vertex_q21];
        fvaly1=((x2-x)/(x2-x1))*inputDatay[vertex_q11] + ((x-x1)/(x2-x1))*inputDatay[vertex_q21];

        fvalx2=((x2-x)/(x2-x1))*inputDatax[vertex_q12] + ((x-x1)/(x2-x1))*inputDatax[vertex_q22];
        fvaly2=((x2-x)/(x2-x1))*inputDatay[vertex_q12] + ((x-x1)/(x2-x1))*inputDatay[vertex_q22];

        fvalx=((y2-y)/(y2-y1))*fvalx1 + ((y-y1)/(y2-y1))*fvalx2;
        fvaly=((y2-y)/(y2-y1))*fvaly1 + ((y-y1)/(y2-y1))*fvaly2;
   


        
            
        
    }

    vect = pair<float,float>(fvalx,fvaly);
    return true;

}
